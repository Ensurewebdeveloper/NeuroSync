
  
        // Initialize Lucide icons
        lucide.createIcons();
        
        // Mobile menu toggle
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenu = document.getElementById('mobile-menu');
        
        mobileMenuButton.addEventListener('click', () => {
            const icon = mobileMenuButton.querySelector('i');
            const isOpen = mobileMenu.classList.toggle('hidden');
            
            if (isOpen) {
                icon.setAttribute('data-lucide', 'menu');
            } else {
                icon.setAttribute('data-lucide', 'x');
            }
            lucide.createIcons();
        });
        
        // FAQ accordion
        document.querySelectorAll('.faq-toggle').forEach(toggle => {
            toggle.addEventListener('click', () => {
                const content = toggle.nextElementSibling;
                const icon = toggle.querySelector('i');
                
                // Toggle content
                content.classList.toggle('hidden');
                
                // Rotate icon
                if (content.classList.contains('hidden')) {
                    icon.setAttribute('data-lucide', 'chevron-down');
                } else {
                    icon.setAttribute('data-lucide', 'chevron-up');
                }
                lucide.createIcons();
            });
        });
        
        // Dark mode toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = themeToggle.querySelector('[data-lucide="sun"]');
        const moonIcon = themeToggle.querySelector('[data-lucide="moon"]');
        
        // Check for saved user preference or use system preference
        if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        } else {
            document.documentElement.classList.remove('dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        }
        
        themeToggle.addEventListener('click', () => {
            // Toggle icons
            sunIcon.classList.toggle('hidden');
            moonIcon.classList.toggle('hidden');
            
            // If set via local storage previously
            if (localStorage.getItem('color-theme')) {
                if (localStorage.getItem('color-theme') === 'light') {
                    document.documentElement.classList.add('dark');
                    localStorage.setItem('color-theme', 'dark');
                } else {
                    document.documentElement.classList.remove('dark');
                    localStorage.setItem('color-theme', 'light');
                }
            } else {
                // If NOT set via local storage previously
                if (document.documentElement.classList.contains('dark')) {
                    document.documentElement.classList.remove('dark');
                    localStorage.setItem('color-theme', 'light');
                } else {
                    document.documentElement.classList.add('dark');
                    localStorage.setItem('color-theme', 'dark');
                }
            }
        });
        
        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('nav-scrolled');
            } else {
                navbar.classList.remove('nav-scrolled');
            }
        });
        
        // Video Modal functionality
        const watchDemoBtn = document.getElementById('watchDemoBtn');
        const videoModal = document.getElementById('videoModal');
        const closeModal = document.getElementById('closeModal');
        const demoVideo = document.getElementById('demoVideo');
        
        watchDemoBtn.addEventListener('click', () => {
            videoModal.style.display = 'flex';
            document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
        });
        
        closeModal.addEventListener('click', () => {
            videoModal.style.display = 'none';
            document.body.style.overflow = 'auto'; // Re-enable scrolling
            
            // Stop the video when modal is closed
            const videoSrc = demoVideo.src;
            demoVideo.src = '';
            demoVideo.src = videoSrc;
        });
        
        // Close modal when clicking outside the video
        videoModal.addEventListener('click', (e) => {
            if (e.target === videoModal) {
                videoModal.style.display = 'none';
                document.body.style.overflow = 'auto';
                
                // Stop the video when modal is closed
                const videoSrc = demoVideo.src;
                demoVideo.src = '';
                demoVideo.src = videoSrc;
            }
        });
        
        // Initialize GSAP animations
        document.addEventListener('DOMContentLoaded', () => {
            // Hero section animations
            gsap.from('.hero-gradient h1', {
                duration: 1,
                y: 50,
                opacity: 0,
                ease: 'power3.out',
                delay: 0.2
            });
            
            gsap.from('.hero-gradient p', {
                duration: 1,
                y: 50,
                opacity: 0,
                ease: 'power3.out',
                delay: 0.4
            });
            
            gsap.from('.hero-gradient a, .hero-gradient button', {
                duration: 1,
                y: 50,
                opacity: 0,
                ease: 'power3.out',
                delay: 0.6,
                stagger: 0.1
            });
            
            gsap.from('.hero-gradient img', {
                duration: 1.5,
                x: 50,
                opacity: 0,
                ease: 'elastic.out(1, 0.5)',
                delay: 0.8
            });
            
            // Trusted by section fade in
            gsap.from('.trusted-by img', {
                duration: 1,
                opacity: 0,
                y: 20,
                stagger: 0.1,
                scrollTrigger: {
                    trigger: '.trusted-by',
                    start: 'top 80%',
                    toggleActions: 'play none none none'
                }
            });
            
            // Feature cards animation
            gsap.from('.feature-card', {
                duration: 0.8,
                y: 50,
                opacity: 0,
                stagger: 0.15,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '#features',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
            
            // Pricing cards animation
            gsap.from('.pricing-card', {
                duration: 0.8,
                y: 50,
                opacity: 0,
                stagger: 0.15,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '#pricing',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
            
            // Testimonial cards animation
            gsap.from('#testimonials .bg-white', {
                duration: 0.8,
                y: 50,
                opacity: 0,
                stagger: 0.15,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '#testimonials',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
            
            // FAQ items animation
            gsap.from('.faq-toggle', {
                duration: 0.8,
                y: 30,
                opacity: 0,
                stagger: 0.1,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '#faq',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
            
            // CTA section animation
            gsap.from('.cta-gradient h2', {
                duration: 0.8,
                y: 30,
                opacity: 0,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '.cta-gradient',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
            
            gsap.from('.cta-gradient p', {
                duration: 0.8,
                y: 30,
                opacity: 0,
                delay: 0.2,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '.cta-gradient',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
            
            gsap.from('.cta-gradient a', {
                duration: 0.8,
                y: 30,
                opacity: 0,
                delay: 0.4,
                ease: 'back.out(1.7)',
                scrollTrigger: {
                    trigger: '.cta-gradient',
                    start: 'top 70%',
                    toggleActions: 'play none none none'
                }
            });
        });
  